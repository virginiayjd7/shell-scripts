# !/bin/bash
#Programa para algunas operaciones utilitarios de postgres

echo "hola bienvein"
