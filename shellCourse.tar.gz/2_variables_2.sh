# !/bin/bash
#programa para revisar la declaracion de variables


echo "Opcion nombre pasada del script anterior:$nombre "
